package application;
 
import java.net.URL;
 
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
 
public class Main extends Application {
    public static void main(String[] args) {
        launch(args);
    }
 
    @Override
    public void start(Stage primaryStage) throws Exception {
    	
        URL url = getClass().getResource("Kalkulator.fxml");
        if (url == null) {
            System.out.println("Can't load FXML file");
            Platform.exit();
        }
        Parent root = FXMLLoader.load(url);
 
        Scene scene = new Scene(root);
 
        primaryStage.setTitle("Kalkulator op�acalno�ci przej�cia na umow� B2B");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}