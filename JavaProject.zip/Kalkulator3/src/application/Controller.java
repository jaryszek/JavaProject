package application;
 
import java.net.URL;
import java.util.ResourceBundle;
 
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
 
public class Controller implements Initializable {
     
    @FXML
    private Button NewButton;
    
    @FXML
    private void pressButton(ActionEvent e) {
        System.out.println("Hello");
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Message Here...");
    }
    
    public void initialize(URL arg0, ResourceBundle arg1) {
        // TODO Auto-generated method stub
         
    }
 
}